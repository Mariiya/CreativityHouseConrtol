create definer = root@localhost trigger insert_request_trigger
    before insert
    on requests
    for each row
BEGIN
SET new.request_date=CURDATE();
END;

