create definer = root@localhost trigger insert_event_action_trigger
    before insert
    on actions
    for each row
BEGIN
DECLARE last_num INT;
SELECT MAX(number) INTO last_num From Actions where event_id=New.event_id;
IF(last_num is not null)
then
SET new.number=last_num+1;
else 
SET new.number=1;
end if;
END;

