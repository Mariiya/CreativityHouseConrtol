create definer = root@localhost trigger insert_event_trigger
    before insert
    on events
    for each row
BEGIN
IF  (NEW.event_date < NOW())
THEN
SIGNAL sqlstate '45001' set message_text = "Wrong even_date";
END IF;
END;

