create definer = root@localhost trigger insert_register_trigger
    before insert
    on register
    for each row
BEGIN
SET NEW.lesson_day_of_week=WEEKDAY(NEW.date)+1;
END;

