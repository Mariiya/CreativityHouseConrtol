create definer = root@localhost trigger insert_action_trigger
    before insert
    on userhistory
    for each row
BEGIN
SET NEW.action_date=CURDATE();
SET NEW.action_time=NOW();
END;

