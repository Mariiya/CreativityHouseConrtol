create definer = root@localhost trigger insert_lesson_trigger
    before insert
    on lessons
    for each row
BEGIN
DECLARE i INT DEFAULT 0;
SELECT COUNT(group_id) INTO i 
FROM Lessons 
WHERE room_id=NEW.room_id 
AND lesson_day_of_week=NEW.lesson_day_of_week
AND time=NEW.time;
IF (i!=0)
THEN
SIGNAL sqlstate '45001' set message_text = "Room is already taken";
END IF;
END;

