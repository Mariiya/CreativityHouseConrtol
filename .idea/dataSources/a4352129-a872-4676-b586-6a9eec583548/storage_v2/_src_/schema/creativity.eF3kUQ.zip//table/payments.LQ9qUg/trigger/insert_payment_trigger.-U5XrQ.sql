create definer = root@localhost trigger insert_payment_trigger
    before insert
    on payments
    for each row
BEGIN
DECLARE v BOOLEAN DEFAULT false;
DECLARE p FLOAT DEFAULT 0;
SELECT verification INTO v FROM Requests 
WHERE member_id=NEW.member_id
AND section_id=(SELECT section_id FROM Groups WHERE group_id=NEW.group_id);
SELECT price INTO p FROM Sections LEFT JOIN Groups ON Groups.section_id=Sections.section_id 
WHERE group_id=NEW.group_id;
IF(v=false ) 
THEN
SIGNAL sqlstate '45001' set message_text = "Request is not approved";
END IF;
IF (p>NEW.amount)
THEN
SIGNAL sqlstate '45001' set message_text = "Amount is not enough";
END IF;
END;

