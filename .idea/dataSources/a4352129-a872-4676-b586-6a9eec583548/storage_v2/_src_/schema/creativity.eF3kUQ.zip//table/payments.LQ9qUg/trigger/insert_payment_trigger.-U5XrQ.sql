create definer = root@localhost trigger insert_payment_trigger
    before insert
    on payments
    for each row
BEGIN
DECLARE p FLOAT DEFAULT 0;
SELECT price INTO p FROM Sections LEFT JOIN Groups ON Groups.section_id=Sections.section_id 
WHERE group_id=NEW.group_id;
IF (p>NEW.amount)
THEN
SIGNAL sqlstate '45001' set message_text = "Amount is not enough";
END IF;
END;

