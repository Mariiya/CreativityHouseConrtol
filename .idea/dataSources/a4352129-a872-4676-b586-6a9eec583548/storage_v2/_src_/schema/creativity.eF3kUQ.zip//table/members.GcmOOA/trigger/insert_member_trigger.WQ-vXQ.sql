create definer = root@localhost trigger insert_member_trigger
    before insert
    on members
    for each row
BEGIN
IF  DATEDIFF(CURRENT_DATE(),NEW.medical_certificate_date)/30 >12
THEN
SIGNAL sqlstate '45001' set message_text = "Medical_certificate_date is overdue";
END IF;
IF NEW.birth_date>NOW()- interval 3 year
THEN
SIGNAL sqlstate '45001' set message_text = "Child must be over 3 years old";
END IF;
END;

