create
    definer = root@localhost function employee_work_hours(employee_id int) returns int
BEGIN 
DECLARE h INT;
SELECT SUM(Lessons.duration)*4/60 INTO h
FROM lessons JOIN groups
ON lessons.group_id=groups.group_id
WHERE manager_id=employee_id
GROUP BY Groups.manager_id;
RETURN h;
END;

