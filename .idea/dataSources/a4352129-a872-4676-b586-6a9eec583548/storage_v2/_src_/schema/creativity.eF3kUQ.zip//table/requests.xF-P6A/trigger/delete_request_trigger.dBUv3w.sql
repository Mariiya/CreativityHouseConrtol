create definer = root@localhost trigger delete_request_trigger
    before delete
    on requests
    for each row
BEGIN
UPDATE Groups SET max_members_num=max_members_num+1 WHERE group_id=(
    SELECT DISTINCT payments.group_id from payments
    LEFT JOIN  `groups`
on payments.group_id = `groups`.group_id
WHERE member_id=OLD.member_id and `groups`.section_id=OLD.section_id);
END;

