create definer = root@localhost trigger uptade_request_trigger
    before update
    on requests
    for each row
BEGIN
UPDATE Groups 
SET max_members_num=max_members_num-1 
WHERE group_id= ANY(
    SELECT DISTINCT payments.group_id 
    from payments
    LEFT JOIN  `groups`
on payments.group_id = `groups`.group_id
WHERE member_id=OLD.member_id 
and `groups`.section_id=OLD.section_id);
END;

