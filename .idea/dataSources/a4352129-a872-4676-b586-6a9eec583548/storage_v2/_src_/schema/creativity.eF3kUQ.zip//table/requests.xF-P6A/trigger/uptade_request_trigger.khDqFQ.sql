create definer = root@localhost trigger uptade_request_trigger
    before update
    on requests
    for each row
BEGIN
DECLARE id INT DEFAULT 0;
SET id=group_search(
    (SELECT datediff(NOW(),birth_date)/365 FROM Members WHERE member_id=NEW.member_id),
    NEW.section_id) ;
IF(OLD.verification=false AND NEW.verification=true)
THEN
UPDATE Groups SET max_members_num=max_members_num-1 WHERE group_id=id;
END IF;
END;

