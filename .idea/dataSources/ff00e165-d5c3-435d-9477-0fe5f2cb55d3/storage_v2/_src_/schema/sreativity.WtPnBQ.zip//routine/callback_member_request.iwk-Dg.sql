create
    definer = root@localhost procedure callback_member_request(IN s_id int, IN n_age int, IN x_age int)
BEGIN 
SELECT member_id, parent_name, parent_phone_number
FROM Members LEFT JOIN Requests 
ON Members.member_id=Requests.member_id 
AND Requests.verification=false 
AND Requests.section_id=s_id
AND datediff(NOW(),Members.birth_date)/365 BETWEEN n_age AND x_age;
END;

