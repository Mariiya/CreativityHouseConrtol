create definer = root@localhost trigger delete_request_trigger
    before delete
    on requests
    for each row
BEGIN
DECLARE id,x_age,n_age INT DEFAULT 0;
SET id=group_search((
    SELECT datediff(NOW(),birth_date)/365 
    FROM Members
    WHERE member_id=OLD.member_id) ,
    OLD.section_id);
SELECT  age_max, age_min INTO x_age,n_age
FROM Groups 
WHERE group_id=id;
UPDATE Groups SET max_members_num=max_members_num+1 WHERE group_id=id;
CALL callback_member_request(OLD.section_id,n_age,x_age);
END;

