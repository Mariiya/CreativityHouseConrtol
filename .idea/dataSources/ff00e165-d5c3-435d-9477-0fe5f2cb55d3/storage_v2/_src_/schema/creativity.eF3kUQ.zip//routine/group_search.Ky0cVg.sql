create
    definer = root@localhost function group_search(age int, s_id int) returns int
BEGIN 
DECLARE g_id INT;
SELECT MIN(Groups.group_id) INTO g_id FROM Groups 
WHERE section_id=s_id 
AND  age BETWEEN Groups.age_min AND Groups.age_max;
RETURN g_id;
END;

